var http = require ('http');
var fs = require('fs');
var formidable = require('formidable');

http.createServer(function(req,res)
{
    if(req.url=='/')
    {
        res.writeHead(200,{'Content-Type':'text/html'});        
        res.write('<form action = "biodata" method="post" enctype="multipart/form-data">');
        res.write('<h1 align="center">Railway Reservation System</h1>');
        res.write('<table border="3" align="center"><tbody><tr><td>Train Number:</td><td><input type="text" name="tno"></td></tr>'+'<tr><td>Train Name:</td><td><input type="text" name="tname"></td></tr>'+'<tr><td>Phone Number:</td><td><input type="text" name="tphno"></td></tr>'+'<tr><td>Date:</td><td><input type="date" name="tdate"></td></tr>'+'<tr><td>Age:</td><td><input type="number" name="tage"></td></tr>'+'<tr><td>Gender:</td><td><input type="radio" id="m" name="gen">Male<input type="radio" id="f" name="gen">Female</td></tr>'+'<tr><td>Source:</td><td><select id="src"><option> Select....</option> <option> Chennai</option><option> Madurai</option><option> Salem<ption</select></td></tr>'+'<tr><td>Destination</td><td><select id="dest"><option> Select....</option> <option> Chennai</option><option> Madurai</option><option> Salem</option></select></td></tr>'+'<tr><td>Type:</td><td><select id="typ"> <option> Select...</option><option>AC</option><option>Non-AC</option></td></tr>'+'<tr><td>Adult:</td><td><input type="text" name="tadult"></td></tr>'+'<tr><td>Child:</td><td><input type="text" name="tchild"></td></tr>'+'<tr><td>Photo:</td><td><input type="file" name="uploadfile"</td></tr>'+'<tr><td>Price:</td><td><input type="text" name="pr"</td></tr></tbody></table>');
      res.write('<input type="submit">');
        res.end();
    }
    else if(req.url == '/biodata')
    {
        var form=new formidable.IncomingForm();
        form.parse(req,function(err,fields,files){
            res.write('<h3>Train Number:' + fields.tno + '</h3><br>');
            res.write('<h3>Train Name:' + fields.tname + '</h3><br>');
            res.write('<h3>Mobile Number:' + fields.tphno + '</h3><br>');
            res.write('<h3>Date:' + fields.tdate + '</h3><br>');
            res.write('<h3>Age:' + fields.tage + '</h3><br>');
            res.write('<h3>Gender:' + fields.gen + '</h3><br>');
            res.write('<h3>Source:' + fields.src + '</h3><br>');
            res.write('<h3>Destination:' + fields.dest + '</h3><br>');
            res.write('<h3>Type:' + fields.typ + '</h3><br>');
           
           
            var oldpath = files.uploadfile.path;
            var newpath='C:\Users\S.Ramya\Desktop/' + files.uploadfile.name;
            fs.rename(oldpath,newpath,function(err){
                {
                  if (err) throw err;
                  res.write('<h1>Your file location</h1><br>');
                  res.write('<h1>old path: ' + oldpath + ' </h1><br>');
                  res.write('<h1>new path: ' + newpath + ' </h1><br>');
                  res.end("<h2>Thank You.Visit Again.Happy Journey</h2>");
                }
            });
            res.write('<h3>Amount:' + fields.pr + '</h3><br>');
        });
    }
    else
    {
      res.end('<h1> 404 PAGE NOT FOUND</h1>');
    }
}).listen(8080);